from django.contrib import admin
from gallery.models import PhotoModel
# Register your models here.
admin.site.register(PhotoModel)